print(".")
