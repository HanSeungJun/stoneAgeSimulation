# https://github.com/ndrplz/google-drive-downloader

import imax
from google_drive_downloader import GoogleDriveDownloader as gdd
import os.path

def google_drive_download(file_id, dest_path):

#	imax.print('file_id: ', file_id)
#	imax.print('dest_path: ', dest_path)

	if dest_path == "":
		imax.print('dest_path does not exist.')
	else:
		gdd.download_file_from_google_drive(file_id,
						dest_path,
						unzip=False, showsize=True, overwrite=True)
	return True
